# Student Academic Performance Prediction — MLP

## Project objective
Use a Multilayer Perceptron (MLP) neural network to predict `final_gpa` from 12 academic/learning features.

## Dataset
Place `Student_Academic_Performance_Final_12_Features.csv` in the same folder as `app.py`.
The application also supports uploading the CSV from the sidebar.

Required target: `final_gpa`  
Inputs: the other 12 columns in the supplied dataset.

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install packages:
   `pip install -r requirements.txt`
4. Start the dashboard:
   `streamlit run app.py`

## How to demonstrate
1. Open Project Overview and explain the 12 inputs and the final_gpa target.
2. Open Train & Evaluate and click Train Neural Network.
3. Explain the network: 12 → 64 → 32 → 16 → 1.
4. Explain that `model.fit()` performs learning through backpropagation and Adam weight updates.
5. Show MAE, RMSE, R², loss curve, and actual-vs-predicted plot.
6. Open Predict Final GPA and enter a sample student's values.

## Important implementation notes
- 80/20 train/test split with `random_state=42`.
- StandardScaler is fitted on training inputs only to avoid data leakage.
- To keep the classroom demo responsive, up to 250,000 training rows are sampled from the training split. The held-out 20% test set remains intact.
- MLPRegressor uses three hidden layers (64, 32, 16), ReLU, Adam, and early stopping.
- This is a regression demonstration, not a validated admissions or grading tool.
