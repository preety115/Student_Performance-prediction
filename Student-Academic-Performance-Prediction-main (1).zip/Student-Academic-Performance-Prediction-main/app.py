import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from pathlib import Path

# ---------------- PAGE CONFIG ----------------
st.set_page_config(
    page_title="Student GPA Predictor",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------------- CLEAN & MODERN THEME ----------------
st.markdown("""
<style>
    .stApp { background-color: #f8fafc; color: #0f172a; }
    
    /* Minimal Sidebar */
    [data-testid="stSidebar"] { background-color: #0f172a; padding-top: 20px; }
    [data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3, 
    [data-testid="stSidebar"] p, [data-testid="stSidebar"] label, [data-testid="stSidebar"] span {
        color: #f8fafc !important;
    }

    /* Header Banner */
    .header-box {
        background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
        padding: 24px 30px;
        border-radius: 12px;
        color: white;
        margin-bottom: 24px;
    }
    .header-box h1 { color: white; margin: 0; font-size: 1.8rem; font-weight: 700; }
    .header-box p { color: #cbd5e1; margin: 6px 0 0 0; font-size: 0.95rem; }

    /* Result Card */
    .result-card {
        background: #ffffff;
        border-left: 6px solid #2563eb;
        padding: 20px 25px;
        border-radius: 10px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        margin-top: 20px;
    }
    .result-value { font-size: 2.5rem; font-weight: 800; color: #1e3a8a; margin: 0; }
    .result-label { font-size: 0.9rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; }

    /* Primary Buttons */
    div.stButton > button {
        background-color: #2563eb;
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.6rem 1.5rem;
        font-weight: 600;
        width: 100%;
    }
    div.stButton > button:hover { background-color: #1d4ed8; color: white; }
</style>
""", unsafe_allow_html=True)

FEATURES = [
    "previous_gpa", "lms_login_frequency", "quiz_avg",
    "coding_practice_hours", "digital_literacy", "revision_hours",
    "attendance_rate", "mental_stress", "video_watch_hours",
    "online_course_hours", "assignment_avg", "study_hours_daily"
]
TARGET = "final_gpa"
DATA_PATH = Path(__file__).parent / "Student_Academic_Performance_Final_12_Features.csv"

# ---------------- DATA LOADING (LOCAL ONLY) ----------------
@st.cache_data
def load_data():
    if DATA_PATH.exists():
        return pd.read_csv(DATA_PATH)
    return None

def validate_data(data):
    missing_cols = [c for c in FEATURES + [TARGET] if c not in data.columns]
    if missing_cols:
        return False, f"Missing columns: {', '.join(missing_cols)}"
    return True, ""

# ---------------- TRAINING FUNCTION ----------------
@st.cache_resource(show_spinner=False)
def train_mlp(dataframe, max_train_rows=250000):
    X = dataframe[FEATURES].astype("float32")
    y = dataframe[TARGET].astype("float32")

    X_train_full, X_test, y_train_full, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )

    if len(X_train_full) > max_train_rows:
        X_train = X_train_full.sample(n=max_train_rows, random_state=42)
        y_train = y_train_full.loc[X_train.index]
    else:
        X_train, y_train = X_train_full, y_train_full

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = MLPRegressor(
        hidden_layer_sizes=(64, 32, 16),
        activation="relu",
        solver="adam",
        learning_rate_init=0.001,
        batch_size=2048,
        max_iter=80,
        early_stopping=True,
        validation_fraction=0.10,
        n_iter_no_change=8,
        random_state=42
    )
    model.fit(X_train_scaled, y_train)

    predictions = model.predict(X_test_scaled)
    metrics = {
        "MAE": mean_absolute_error(y_test, predictions),
        "RMSE": np.sqrt(mean_squared_error(y_test, predictions)),
        "R2": r2_score(y_test, predictions)
    }
    result = pd.DataFrame({"Actual GPA": y_test.to_numpy(), "Predicted GPA": predictions})
    return model, scaler, metrics, model.loss_curve_, result

# ---------------- CLEAN SIDEBAR (ONLY TITLE) ----------------
st.sidebar.markdown("## 🎓 GPA Predictor")

df = load_data()

if df is None:
    st.error("Dataset file `Student_Academic_Performance_Final_12_Features.csv` not found in the project folder!")
    st.stop()

valid, message = validate_data(df)
if not valid:
    st.error(message)
    st.stop()

df = df[FEATURES + [TARGET]].apply(pd.to_numeric, errors="coerce").dropna()

# Auto-train on background silently
if "mlp_model" not in st.session_state:
    with st.spinner("Initializing neural network..."):
        model, scaler, metrics, history, result = train_mlp(df)
        st.session_state["mlp_model"] = model
        st.session_state["mlp_scaler"] = scaler
        st.session_state["mlp_metrics"] = metrics
        st.session_state["mlp_history"] = history
        st.session_state["mlp_result"] = result

# ---------------- MAIN HEADER ----------------
st.markdown("""
<div class="header-box">
  <h1>Student Academic Performance Prediction</h1>
  <p>Enter student metrics below to estimate final GPA using Neural Network (MLP)</p>
</div>
""", unsafe_allow_html=True)

# ---------------- CLEAN TOP TABS ----------------
tab1, tab2 = st.tabs(["🎯 Predict Final GPA", "📊 Model Evaluation"])

# TAB 1: PREDICTION
with tab1:
    defaults = df[FEATURES].median()
    inputs = {}
    
    cols = st.columns(3)
    for i, feature in enumerate(FEATURES):
        col = cols[i % 3]
        minimum = float(df[feature].min())
        maximum = float(df[feature].max())
        default = float(defaults[feature])
        
        with col:
            inputs[feature] = st.number_input(
                feature.replace("_", " ").title(),
                min_value=minimum,
                max_value=maximum,
                value=min(max(default, minimum), maximum),
                step=0.1
            )

    st.markdown("<br>", unsafe_allow_html=True)
    col_btn, col_res = st.columns([1, 2])
    
    with col_btn:
        predict_clicked = st.button("Calculate Predicted GPA")
        
    if predict_clicked:
        row = pd.DataFrame([[inputs[f] for f in FEATURES]], columns=FEATURES)
        scaled = st.session_state["mlp_scaler"].transform(row)
        prediction = float(st.session_state["mlp_model"].predict(scaled)[0])
        
        with col_res:
            st.markdown(f"""
            <div class="result-card">
                <div class="result-label">Estimated Final GPA</div>
                <div class="result-value">{prediction:.2f}</div>
            </div>
            """, unsafe_allow_html=True)

# TAB 2: EVALUATION & RETRAIN
with tab2:
    metrics = st.session_state["mlp_metrics"]
    
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("R² Score (Accuracy)", f'{metrics["R2"]:.4f}')
    m2.metric("MAE (Mean Error)", f'{metrics["MAE"]:.4f}')
    m3.metric("RMSE", f'{metrics["RMSE"]:.4f}')
    if m4.button("🔄 Retrain Model"):
        st.cache_resource.clear()
        st.rerun()

    st.markdown("---")
    c1, c2 = st.columns(2)
    
    with c1:
        st.markdown("**Training Loss Curve**")
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(st.session_state["mlp_history"], color="#2563eb", linewidth=2)
        ax.set_xlabel("Iterations")
        ax.set_ylabel("Loss (MSE)")
        ax.grid(alpha=0.2)
        st.pyplot(fig)
        plt.close(fig)

    with c2:
        st.markdown("**Actual vs Predicted GPA**")
        sample = st.session_state["mlp_result"].sample(
            min(1000, len(st.session_state["mlp_result"])), random_state=42
        )
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.scatter(sample["Actual GPA"], sample["Predicted GPA"], alpha=0.4, s=15, color="#1e3a8a")
        low, high = min(sample.min()), max(sample.max())
        ax.plot([low, high], [low, high], linestyle="--", color="#ef4444")
        ax.set_xlabel("Actual GPA")
        ax.set_ylabel("Predicted GPA")
        ax.grid(alpha=0.2)
        st.pyplot(fig)
        plt.close(fig) 